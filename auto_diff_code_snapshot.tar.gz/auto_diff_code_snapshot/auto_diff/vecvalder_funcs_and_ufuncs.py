from .vecvalder import register, VecValDer
import warnings
from . import true_np as np
import numpy as modded_np

cls = VecValDer


class FeaturelessVecValDer:
    __slots__ = 'val', 'der'

    def __init__(self, val, der):
        self.val = val
        self.der = der


_none_vec_val_der = FeaturelessVecValDer(None, None)
# Define a decorator which adds out support, erroring on non-vecvalder entries
# and replacing it with objects that can be treated as non-trivial ones


# This is probably a good C/Cython candidate
def _chain_rule(f_x, dx):
    r"""This implements the chain rule for the elementwise application  of
        f: R -> R
    Meant to implement for f: R -> R, g: R^n -> R, x \in R^n
    \nabla f(g(x)) = f'(g(x)) \nabla g(x)
    """
    out = np.ndarray(dx.shape)  # Uninitialized memory is fine because we're
    # about to
    # overwrite each element. If we do compression of the for loop in the
    # future be sure to swtich to np.zeros.
    for index, y in np.ndenumerate(f_x):
        out[index] = y * dx[index]
    return out


@register(np.transpose)
def transpose(a, axes=None):
    assert isinstance(a, cls)
    val = np.transpose(a.val, axes)
    dims = len(val.shape)
    if axes is None:
        axes = reversed(range(dims))
    der = np.transpose(a.der, (*axes, *range(dims, 2 * dims)))
    return cls(val, der)


# Tested
@register(np.absolute)
def absolute(x):
    """WARNING: Computes the derivative of |x| at 0 as 0."""
    val = np.absolute(x.val)
    der_mask = np.sign(x.val)

    small_mask = (val <= 1e-12)
    if (small_mask).any():
        warnings.warn('abs of a near-zero number, derivative is ill-defined')
        der_mask[small_mask] = 0

    der = _chain_rule(der_mask, x.der)
    return cls(val, der)


abs = absolute


# Tested
@register(np.sqrt)
def sqrt(x):
    val = np.sqrt(x.val)
    return cls(val, _chain_rule(0.5 / val, x.der))


# Tested
@register(np.sin)
def sin(x):
    return cls(np.sin(x.val), _chain_rule(np.cos(x.val), x.der))


# Tested
@register(np.cos)
def cos(x):
    return cls(np.cos(x.val), _chain_rule(-np.sin(x.val), x.der))


# Tested
@register(np.tan)
def tan(x):
    return cls(np.tan(x.val), _chain_rule(1.0/(np.cos(x.val)**2), x.der))


# Tested
@register(np.arcsin)
def arcsin(x):
    return cls(np.arcsin(x.val), _chain_rule(1 / np.sqrt(1 - x.val**2), x.der))


# Tested
@register(np.arccos)
def arccos(x):
    return cls(np.arccos(x.val),
               _chain_rule(-1.0 / np.sqrt(1 - x.val**2), x.der))


# Tested
@register(np.arctan)
def arctan(x):
    return cls(np.arctan(x.val), _chain_rule(1.0 / (1 + x.val**2), x.der))


# Tested
@register(np.exp)
def exp(x):
    val = np.exp(x.val)
    return cls(val, _chain_rule(val, x.der))


# Tested
@register(np.log)
def log(x):
    return cls(np.log(x.val), _chain_rule(1.0 / x.val, x.der))


# Tested
@register(np.log2)
def log2(x):
    return cls(np.log2(x.val), _chain_rule(1.0 / np.log(2) / x.val, x.der))


# Tested
@register(np.log10)
def log10(x):
    return cls(np.log10(x.val), _chain_rule(1.0 / np.log(10) / x.val, x.der))


# Tested
@register(np.log1p)
def log1p(x):
    return cls(np.log1p(x.val), _chain_rule(1.0 / (1 + x.val), x.der))


# Tested
@register(np.negative)
def negative(x):
    return cls(-x.val, -x.der)


# Tested
@register(np.positive)
def positive(x):
    return cls(+x.val, +x.der)


# Tested
@register(np.add)
def add(x1, x2, out=None):
    if out is None:
        out = _none_vec_val_der
    else:
        out = out[0]

    if isinstance(x1, cls) and isinstance(x2, cls):
        return cls(np.add(x1.val, x2.val, out=out.val),
                   np.add(x1.der, x2.der, out=out.der))
    elif isinstance(x1, cls):
        return cls(np.add(x1.val, x2, out=out.val),
                   np.add(x1.der, 0, out=out.der))
    elif isinstance(x2, cls):
        return cls(np.add(x1, x2.val, out=out.val),
                   np.add(x2.der, 0, out=out.der))
    else:
        raise RuntimeError("This should not be occuring.")


# Tested
@register(np.subtract)
def subtract(x1, x2):
    if isinstance(x1, cls) and isinstance(x2, cls):
        return cls(x1.val - x2.val, x1.der - x2.der)
    elif isinstance(x1, cls):
        return cls(x1.val - x2, x1.der)
    elif isinstance(x2, cls):
        return cls(x1 - x2.val, -x2.der)
    else:
        raise RuntimeError("This should not be occuring.")


# Tested
@register(np.multiply)
def multiply(x1, x2):
    if isinstance(x1, cls) and isinstance(x2, cls):
        return cls(x1.val * x2.val, x1.der * x2.val + x1.val * x2.der)
    elif isinstance(x1, cls):
        return cls(x1.val * x2, x1.der * x2)
    elif isinstance(x2, cls):
        return cls(x1 * x2.val, x1 * x2.der)
    else:
        raise RuntimeError("This should not be occuring.")


# Tested
@register(np.true_divide)
def true_divide(x1, x2):
    if isinstance(x1, cls) and isinstance(x2, cls):
        return cls(x1.val / x2.val,
                   (x1.der * x2.val - x1.val * x2.der) / x2.val**2)
    elif isinstance(x1, cls):
        return cls(x1.val / x2, (x1.der * x2) / x2**2)
    elif isinstance(x2, cls):
        return cls(x1 / x2.val, (-x1 * x2.der) / x2.val**2)
    else:
        raise RuntimeError("This should not be occuring.")


# Tested
@register(np.float_power)
def float_power(x1, x2):
    if isinstance(x1, cls) and isinstance(x2, cls):
        return cls(x1.val ** x2.val, x1.val**(x2.val - 1) * (
            x2.val * x1.der + x1.val * np.log(x1.val) * x2.der))
    elif isinstance(x1, cls):
        return cls(x1.val ** x2, x1.val**(x2 - 1) * x2 * x1.der)
    elif isinstance(x2, cls):
        return cls(x1.val ** x2.val, x1**(x2.val) * np.log(x1.val) * x2.der)
    else:
        raise RuntimeError("This should not be occuring.")


@register(np.power)
def power(x1, x2):
    return float_power(x1, x2)


# Partially Tested
@register(np.matmul)
def matmul(x1, x2):
    if isinstance(x1, cls) and isinstance(x2, cls):
        val = x1.val @ x2.val
        # Find a way to write der as numpy primitives.
        # C/Cython candidate
        der = np.ndarray((*val.shape, *x1.der.shape[-2:]))
        for i, k in modded_np.ndindex(val.shape):
            der[i, k] = sum(
                x1.val[i, j] * x2.der[j, k] + x1.der[i, j] * x2.val[j, k]
                for j in range(x1.shape[1]))
        return cls(val, der)

    elif isinstance(x1, cls):
        val = x1.val @ x2
        # Find a way to write der as numpy primitives.
        # C/Cython candidate
        der = np.ndarray((*val.shape, *x1.der.shape[-2:]))
        for i, k in modded_np.ndindex(val.shape):
            der[i, k] = sum(x1.der[i, j] * x2[j, k]
                            for j in range(x1.shape[1]))
        return cls(val, der)

    elif isinstance(x2, cls):
        val = x1 @ x2.val
        # Find a way to write der as numpy primitives.
        # C/Cython candidate
        der = np.ndarray((*val.shape, *x2.der.shape[-2:]))
        for i, k in modded_np.ndindex(val.shape):
            der[i, k] = sum(x1[i, j] * x2.der[j, k]
                            for j in range(x1.shape[1]))
        return cls(val, der)
    else:
        raise RuntimeError("This should not be occuring.")


@register(np.linalg.norm)
def norm(x, ord=None):
    assert ord is None or ord == 2
    return (x.T @ x)[0, 0]


# Comparison methods
@register(np.equal)
def equal(x1, x2):
    if isinstance(x1, cls) and isinstance(x2, cls):
        return x1.val == x2.val
    elif isinstance(x1, cls):
        return x1.val == x2
    elif isinstance(x2, cls):
        return x1 == x2.val
    else:
        raise RuntimeError("This should not be occuring.")


@register(np.less)
def less(x1, x2):
    if isinstance(x1, cls) and isinstance(x2, cls):
        return x1.val < x2.val
    elif isinstance(x1, cls):
        return x1.val < x2
    elif isinstance(x2, cls):
        return x1 < x2.val
    else:
        raise RuntimeError("This should not be occuring.")


@register(np.greater)
def greater(x1, x2):
    if isinstance(x1, cls) and isinstance(x2, cls):
        return x1.val > x2.val
    elif isinstance(x1, cls):
        return x1.val > x2
    elif isinstance(x2, cls):
        return x1 > x2.val
    else:
        raise RuntimeError("This should not be occuring.")


@register(np.less_equal)
def less_equal(x1, x2):
    if isinstance(x1, cls) and isinstance(x2, cls):
        return x1.val <= x2.val
    elif isinstance(x1, cls):
        return x1.val <= x2
    elif isinstance(x2, cls):
        return x1 <= x2.val
    else:
        raise RuntimeError("This should not be occuring.")


@register(np.greater_equal)
def greater_equal(x1, x2):
    if isinstance(x1, cls) and isinstance(x2, cls):
        return x1.val >= x2.val
    elif isinstance(x1, cls):
        return x1.val >= x2
    elif isinstance(x2, cls):
        return x1 >= x2.val
    else:
        raise RuntimeError("This should not be occuring.")


@register(np.not_equal)
def not_equal(x1, x2):
    if isinstance(x1, cls) and isinstance(x2, cls):
        return x1.val != x2.val
    elif isinstance(x1, cls):
        return x1.val != x2
    elif isinstance(x2, cls):
        return x1 != x2.val
    else:
        raise RuntimeError("This should not be occuring.")


@register(np.isfinite)
def isfinite(x):
    return np.isfinite(x.val)
